/**
 * REMARK.
 *
 * This controller will mainly control behaviors of "store.html"
 * 
 */

app.controller('storeController', function($scope, $http){
	//Load heading titles
	$scope.headingTitle = "Product List";
	$scope.modHead = "Model";
	$scope.yrHead = "Year";
	$scope.prHead = "Price";
	$scope.pdcHead = "Producer";
	$scope.qttHead = "Available";
	$scope.actHead = "Action";
	$scope.secondHead = "Add new product";
	
	//Load the list
	$http.get('data/post.json').then(function(res){
		$scope.products = res.data;
	});
	
	//Remove an item out of the list
	$scope.removeRow = function(name){				
		var index = -1;		
		var listArr = eval( $scope.products );
		for( var i = 0; i < listArr.length; i++ ) {
			if( listArr[i].Model === name ) {
				index = i;
				break;
			}
		}
	//In case the list is empty
		if( index === -1 ) {
			alert( "Something went wrong!" );
		}
		$scope.products.splice( index, 1 );		
	};
	
	//Add a new item to the list
	$scope.addRow = function() {
		$scope.products.push({'Model':$scope.Model, 'Year':$scope.Year, 'Price':$scope.Price, 'Producer':$scope.Producer, 'Available':$scope.Available});
		$scope.Model = '';
		$scope.Year = '';
		$scope.Price = '';
		$scope.Producer = '';
		$scope.Available = '';
	};
	
	//Error Messages
	$scope.errBlank = "Field must be fill";
	$scope.errLength = "At least 5 characters!";
	$scope.errYear = "Only 4 numbers!";
	$scope.errNumber = "Not a valid number!";
	$scope.errPrice1 = "At least 3 numbers!";
	$scope.errPrice2 = "Maximum is 9 numbers!";
	$scope.errQuantity1 = "At least 1 ";
	$scope.errQuantity2 = "At least 6 ";
	
});

//Convert to number
app.filter('toNum', function(){
	return function(input){
		return parseInt(input, 10);
	};
});

