/**
 * REMARK.
 * 
 * These scripts will be used to register needed controllers
 */
var app = angular.module('storeApp', ['ngRoute','ngResource']);

app.config(function($routeProvider){
	$routeProvider
	.when('/product',{
        templateUrl: '/storeonline/views/store.html',
        controller: 'storeController'
    })
    .otherwise(
    		{ redirectTo: '/'}
    );
});