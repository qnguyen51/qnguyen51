/**
 * REMARK.
 * 
 * This class will be used to init the app at the first launch
 * 
 * */
package com.store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableAutoConfiguration
@ComponentScan("com.store")
public class StoreonlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(StoreonlineApplication.class, args);
	}
}
